#!/usr/bin/python
# Zhenpeng Zhou <zhenp3ngzhou cir{a} gmail dot com>
# Fri Nov 17 2017


from .sifreader import SIFFile
